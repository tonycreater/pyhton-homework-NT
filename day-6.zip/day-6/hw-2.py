x = [[10, 20], [40], [30, 56, 25], [10, 20], [33], [40]]

def func(x):
    x1 = []
    for i in x:    
        if i not in x1:
            x1.append(i)
    print(x1)
func(x)