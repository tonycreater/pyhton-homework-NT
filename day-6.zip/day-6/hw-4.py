a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
b = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
new = []
def func(a, b):
    x = list(set(a) & set(b))
    for i in x:
        new.append(i)
    print(new)
func(a,b)