list1 = [1,2,3]
list2 = [11,22,33]
def mlists(list1, list2):
    result = []
    min_len = min(len(list1), len(list2))

    for i in range(min_len):
        result.append(list1[i])
        result.append(list2[i])
    

    result.extend(list1[min_len:])
    result.extend(list2[min_len:])
    
    return result

print(mlists(list1,list2))
