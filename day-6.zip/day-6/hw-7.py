matn = input("String kiriting: ")
belgilar = {}

for harf in matn:
    if harf in belgilar:
        belgilar[harf] += 1
    else:
        belgilar[harf] = 1

print(belgilar)