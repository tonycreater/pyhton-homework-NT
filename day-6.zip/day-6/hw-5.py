N = int(input("N = "))
sonlar = []

for i in range(N):
    son = int(input(f"{i+1}-sonni kiriting: "))
    sonlar.append(son)

natija = []

for son in sonlar:
    if sonlar.count(son) > 1:
        natija.append(son)
print("sonlar =", natija)