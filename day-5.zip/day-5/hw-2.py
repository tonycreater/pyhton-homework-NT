movies = {
    "Titanic": 1997,
    "Avatar": 2009,
    "Inception": 2010,
    "Interstellar": 2014
}
print("2000-yilda va undan keyin chiqgan kinolar ro'yxati:")
for i in movies:
    if movies[i] >= 2000:
        print(f"nomi: {i}\nyili: {movies[i]}")