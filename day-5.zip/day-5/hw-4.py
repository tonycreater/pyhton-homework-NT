professions = {
    "Bill Gates": "Dasturchi",
    "Cristiano Ronaldo": "Futbolchi",
    "Elon Musk": "Tadbirkor",
    "Messi": "Futbolchi"
}

name = input("Ism kiriting: ")

if name in professions:
    print(f"{name} kasbi: {professions[name]}")
else:
    print("Bunday shaxs topilmadi")