cars = {
    "Malibu": 35000,
    "Spark": 12000,
    "Cobalt": 18000,
    "Tracker": 28000
}
maxx = cars["Cobalt"]
minn = cars["Cobalt"]
for i in cars:
    if cars[i] > maxx:
        car1 = i
        maxx = cars[i]
    if cars[i] < minn:
        car2 = i 
        minn = cars[i]

avg = sum(cars.values()) / len(cars)

print(f"eng qimmat mashina: {car1} narxi: {maxx}")
print(f"eng arzon mashina: {car2} narxi: {minn}")
print(f"hamma mashinalarni o'rtacha qiymati: {avg}")