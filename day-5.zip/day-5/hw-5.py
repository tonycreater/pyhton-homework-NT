car_count = {
    "Chevrolet": 120,
    "Toyota": 95,
    "BMW": 60,
    "Kia": 75
}

maxx = max(car_count, key=car_count.get)
minn = min(car_count, key=car_count.get)

print(f"Eng ko‘p sotilgan: {maxx} - {car_count[maxx]} ta")
print(f"Eng kam sotilgan: {minn} - {car_count[minn]} ta")