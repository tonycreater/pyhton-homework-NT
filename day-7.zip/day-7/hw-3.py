def ombor_info(ombor):
    jami = 0

    for mahsulot in ombor:
        jami += mahsulot["miqdor"]

    sort = sorted(ombor, key=lambda x: x["miqdor"])

    eng_kam = []

    for item in sort[:3]:
        eng_kam.append(item["mahsulot"])

    return jami, eng_kam


ombor = [
    {"mahsulot": "olma", "miqdor": 5},
    {"mahsulot": "nok", "miqdor": 9},
    {"mahsulot": "shaftoli", "miqdor": 7},
    {"mahsulot": "anor", "miqdor": 4},
    {"mahsulot": "banan", "miqdor": 6},
    {"mahsulot": "uzum", "miqdor": 8},
    {"mahsulot": "gilos", "miqdor": 2},
    {"mahsulot": "tarvuz", "miqdor": 1},
    {"mahsulot": "qovun", "miqdor": 3},
    {"mahsulot": "limon", "miqdor": 5}
]

jami, eng_kam = ombor_info(ombor)

print("Umumiy mahsulotlar miqdori:", jami)
print("Eng kam qolgan 3 ta mahsulot:", ", ".join(eng_kam))