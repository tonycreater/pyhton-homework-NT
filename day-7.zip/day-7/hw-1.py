def func(matn):
    sozlar = matn.split()
    sanoq = {}

    for soz in sozlar:
        sanoq[soz] = sanoq.get(soz, 0) + 1

    tartiblangan = sorted(sanoq.items(), key=lambda x: x[1], reverse=True)

    natija = [soz for soz, soni in tartiblangan[:3]]

    return " ".join(natija)


matn = input("text kiriting: ")
print(func(matn))