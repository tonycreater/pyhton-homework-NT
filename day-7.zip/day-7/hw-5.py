def clear(mylist):
    natija = []

    for soz in mylist:
        if soz != "" and soz not in natija:
            natija.append(soz)

    return natija


mylist = ["olma", "", "olma", "gilos", ""]

print(clear(mylist))