def sort_keys(my_dict):
    sort = sorted(my_dict.items(), key=lambda x: x[1])

    for kalit, qiymat in sort:
        print(kalit)


my_dict = {
    "t": 3,
    "p": 1,
    "y": 2,
    "o": 5,
    "h": 4,
    "n": 6,
}

sort_keys(my_dict)