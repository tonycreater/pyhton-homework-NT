def avg(students):
    natija = {}

    for ism, fanlar in students.items():
        jami = sum(fanlar.values())
        soni = len(fanlar)
        natija[ism] = jami / soni

    return natija


students = {
    "Ali": {"math": 90, "en": 80},
    "Vali": {"math": 70, "en": 85}
}

result = avg(students)

for ism, ball in result.items():
    print(f"{ism}: {ball}")