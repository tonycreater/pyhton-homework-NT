x = int(input("3 xonali son kiriting: "))
one = 0
two = 0
three = 0
one += x % 10
x = x // 10
two = x % 10
x = x // 10
three = x % 10

print(f"{two}{one}{three}")