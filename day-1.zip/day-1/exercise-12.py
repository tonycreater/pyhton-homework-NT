x = int(input("4 xonali son kiriting: "))
# one = 0
# two = 0
# three = 0
# four = 0
one = x % 10
x = x // 10
two = x % 10
x = x // 10
three = x % 10
x = x // 10
four = x % 10
print(f"{three}{two}{one}{four}")