x = int(input("3 xonali son kiriting: "))
y = 0

y += x % 10
x = x // 10

y += x % 10
x = x // 10

y += x % 10

print(y)