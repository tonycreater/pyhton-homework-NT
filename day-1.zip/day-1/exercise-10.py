x = int(input("4-xonali son kiriting: "))
max_num = 0
while x > 0:
    digit = x % 10
    if digit > max_num:
        max_num = digit
    x = x // 10

print(f"Kiritgan soningizni ichidagi eng katta raqami: {max_num}")
