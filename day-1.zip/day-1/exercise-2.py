x = int(input("2-xonali son kiriting: "))
qoldiq = x % 10
butun = x // 10
summa = qoldiq + butun
print(f"Sonlar yig'indisi: {summa}")