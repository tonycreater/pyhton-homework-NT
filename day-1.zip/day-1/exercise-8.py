x = int(input("2-xonali son kiriting: "))
qoldiq = x % 10

if(qoldiq % 2 == 0):
    print("Juft")
else:
    print("Toq")