x = int(input("2-xonali son kiriting: "))
qoldiq = x % 10
butun = x // 10
print(f"{butun} {qoldiq}")