x = int(input("3 xonali son kiriting: "))
birlar = x % 10
yuzlar = x // 100
print(yuzlar+birlar)