s1 = {'olma', 'anor', 'youtube', 'instagram', 'gilos'}
s2 = {'youtube', 'gilos', 'anor', 'BMW', 'Tesla', 'Nissan'}
s3 = {'gilos', 'olma', 'instagram', 'Tesla', 'Nissan'}

result = (s1 & s2) - s3
print(*result)