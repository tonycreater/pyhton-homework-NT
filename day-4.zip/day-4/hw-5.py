s1 = input("1-so'z: ")
s2 = input("2-so'z: ")

result = sorted(s1) == sorted(s2)
print(result)