s1 = {1,2,3,4,5,6}
s2 = {4,5,6,7,8,9}

common_sum = sum(s1 & s2)
only_set1_sum = sum(s1 - s2)

result = common_sum - only_set1_sum
print(result)