s1 = {4,5,6,7,8,9}
s2 = {5,6,7,10,11}

non_common_sum = sum(s1 ^ s2)
common_sum = sum(s1 & s2)

result = non_common_sum - common_sum
print(result)