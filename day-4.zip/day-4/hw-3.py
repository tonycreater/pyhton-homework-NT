s1 = {1,2,3,4,5,6}
s2 = {4,5,6,7,8,9}

result = sorted((s1 ^ s2), reverse=True)
print(*result)