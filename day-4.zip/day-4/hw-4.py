ali = {"Toshkent", "Samarqand", "Buxoro", "Andijon"}
vali = {"Toshkent", "Farg'ona", "Buxoro", "Xiva"}

both = ali & vali
only_ali = ali - vali

print("Ikkalasi ham borgan:", both)
print("Faqat Ali borgan:", only_ali)