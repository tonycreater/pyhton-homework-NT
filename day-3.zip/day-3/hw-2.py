t=(1,2,3,4,5,6,7,8,9,10)
print(f"4-element: {t[3]} oxiridan 4-element: {t[-4]}")