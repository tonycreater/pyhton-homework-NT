x = input("text kiriting: ")

result = []

for i in x:
    result.append(i)
print(tuple(result))