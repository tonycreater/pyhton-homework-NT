l = [1, 2, 3, 4]
s = "emp"

result = []
for i in l:
    result.append(s + str(i))

print(result)