x = int(input("son kiriting: "))
y = int(input("son kiriting: "))

sonlar = []
for i in range(x, y):
    if i % 2 == 0:
        sonlar.append(i)
print(sonlar)