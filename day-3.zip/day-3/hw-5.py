x = [ [1,2,3], [4,5,6], [10,11,12], [7,8,9] ]

max_sum = max(sum(i) for i in x)
print(max_sum)